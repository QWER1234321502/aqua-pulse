-- Supabase > SQL Editor 에서 한 번만 실행하세요.

create table if not exists shop_members (
  id            bigint generated always as identity primary key,
  email         text unique not null,
  name          text not null,
  phone         text not null,
  password_hash text not null,
  points        integer not null default 0,
  grade         text not null default '브론즈',
  total_spent   integer not null default 0,
  created_at    timestamptz not null default now()
);

create table if not exists shop_orders (
  id            bigint generated always as identity primary key,
  member_email  text not null references shop_members(email),
  items         jsonb not null,
  total         integer not null,
  used_points   integer not null default 0,
  earned_points integer not null default 0,
  status        text not null default '배송 준비중',
  created_at    timestamptz not null default now()
);

-- 수업/실습용: anon 키로 접근 가능하게 허용 (실서비스에서는 Supabase Auth + 엄격한 정책 필요)
alter table shop_members enable row level security;
alter table shop_orders  enable row level security;

create policy "members_all" on shop_members for all to anon using (true) with check (true);
create policy "orders_all"  on shop_orders  for all to anon using (true) with check (true);
