/* ============================================================
   script.js — AQUA WAVE 화면 로직 (db.js 의 DB, PRODUCTS 사용)
   ============================================================ */

let currentUser = null;
let cart = LS.get('aw_cart', []);           // [{id, qty}]
let activeCat = '전체';
let searchKeyword = '';

const won = n => Number(n).toLocaleString('ko-KR') + '원';
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = id => document.getElementById(id);

const GRADES = [
  { name: '브론즈', min: 0,      rate: 0.01 },
  { name: '실버',   min: 100000, rate: 0.02 },
  { name: '골드',   min: 300000, rate: 0.03 }
];
const gradeOf = spent => [...GRADES].reverse().find(g => spent >= g.min);

/* ---------- 토스트 ---------- */
function toast(msg, isError) {
  let t = $('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.className = 'show' + (isError ? ' error' : '');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (t.className = ''), 2800);
}

/* ---------- 화면 전환 ---------- */
function navigate(view) {
  if (view === 'mypage' && !currentUser) { openAuthModal(); return; }
  ['home', 'cart', 'mypage'].forEach(v => $('view-' + v).classList.toggle('hidden', v !== view));
  if (view === 'cart') renderCart();
  if (view === 'mypage') renderMyPage();
  window.scrollTo(0, 0);
}

/* ---------- 모달 ---------- */
function openModal(id) { $(id).classList.remove('hidden'); }
function closeModal(id) { $(id).classList.add('hidden'); }
function openAuthModal() { switchAuthTab('login'); openModal('auth-modal'); }
function switchAuthTab(tab) {
  const isLogin = tab === 'login';
  $('tab-login').classList.toggle('active', isLogin);
  $('tab-signup').classList.toggle('active', !isLogin);
  $('login-form').classList.toggle('hidden', !isLogin);
  $('signup-form').classList.toggle('hidden', isLogin);
}
document.addEventListener('click', e => {
  if (e.target.classList && e.target.classList.contains('modal')) e.target.classList.add('hidden');
});

/* ---------- 회원가입 / 로그인 / 로그아웃 ---------- */
async function handleSignup(e) {
  e.preventDefault();
  const btn = e.target.querySelector('button[type=submit]');
  btn.disabled = true;
  try {
    const member = await DB.signup({
      name: $('signup-name').value,
      phone: $('signup-phone').value,
      email: $('signup-email').value,
      password: $('signup-pw').value
    });
    setUser(member);
    e.target.reset();
    closeModal('auth-modal');
    toast(`🎉 ${member.name}님 가입 완료! ${won(SIGNUP_BONUS).replace('원', 'P')}가 지급되었어요.`);
  } catch (err) {
    toast(err.message, true);
  } finally {
    btn.disabled = false;
  }
}

async function handleLogin(e) {
  e.preventDefault();
  const btn = e.target.querySelector('button[type=submit]');
  btn.disabled = true;
  try {
    const member = await DB.login($('login-email').value, $('login-pw').value);
    setUser(member);
    e.target.reset();
    closeModal('auth-modal');
    toast(`${member.name}님 환영합니다!`);
  } catch (err) {
    toast(err.message, true);
  } finally {
    btn.disabled = false;
  }
}

function setUser(member) {
  currentUser = member;
  if (member) LS.set('aw_session', member.email);
  else localStorage.removeItem('aw_session');
  updateAuthUI();
}

function logout() {
  setUser(null);
  navigate('home');
  toast('로그아웃 되었습니다.');
}

function updateAuthUI() {
  $('nav-auth-btn').classList.toggle('hidden', !!currentUser);
  $('nav-mypage-btn').classList.toggle('hidden', !currentUser);
  if (currentUser) $('nav-mypage-btn').textContent = `${currentUser.name}님 (${currentUser.points.toLocaleString()}P)`;
}

async function restoreSession() {
  const email = LS.get('aw_session', null);
  if (!email) return;
  try {
    const m = await DB.getMember(email);
    if (m) { currentUser = (({ password_hash, ...r }) => r)(m); updateAuthUI(); }
  } catch (e) { /* 무시 */ }
}

/* ---------- 상품 목록 ---------- */
function renderProducts() {
  const kw = searchKeyword.trim().toLowerCase();
  const list = PRODUCTS.filter(p =>
    (activeCat === '전체' || p.cat === activeCat) &&
    (!kw || p.name.toLowerCase().includes(kw) || p.desc.toLowerCase().includes(kw))
  );
  $('product-grid').innerHTML = list.length
    ? list.map(p => `
      <div class="product-card" onclick="openProduct(${p.id})">
        <div class="product-thumb">${p.emoji}</div>
        <div class="product-info">
          <span class="product-cat">${esc(p.cat)}</span>
          <h3>${esc(p.name)}</h3>
          <p class="price">${won(p.price)}</p>
        </div>
      </div>`).join('')
    : '<p class="empty">검색 결과가 없습니다.</p>';
}

function openProduct(id) {
  const p = PRODUCTS.find(x => x.id === id);
  $('product-modal-body').innerHTML = `
    <div class="detail-thumb">${p.emoji}</div>
    <span class="product-cat">${esc(p.cat)}</span>
    <h2>${esc(p.name)}</h2>
    <p>${esc(p.desc)}</p>
    <p class="price big">${won(p.price)}</p>
    <button type="button" class="btn-primary full-width" onclick="addToCart(${p.id}); closeModal('product-modal')">장바구니 담기</button>`;
  openModal('product-modal');
}

/* ---------- 장바구니 ---------- */
function saveCart() { LS.set('aw_cart', cart); updateBadge(); }
function updateBadge() { $('cart-badge').textContent = cart.reduce((s, c) => s + c.qty, 0); }

function addToCart(id) {
  const item = cart.find(c => c.id === id);
  if (item) item.qty++; else cart.push({ id, qty: 1 });
  saveCart();
  toast('장바구니에 담았어요 🐠');
}
function changeQty(id, d) {
  const item = cart.find(c => c.id === id);
  if (!item) return;
  item.qty += d;
  if (item.qty <= 0) cart = cart.filter(c => c.id !== id);
  saveCart();
  renderCart();
}
function cartTotal() { return cart.reduce((s, c) => s + PRODUCTS.find(p => p.id === c.id).price * c.qty, 0); }
const SHIPPING_FEE = 5000, FREE_SHIPPING = 30000;

function renderCart() {
  const box = $('cart-content');
  if (!cart.length) { box.innerHTML = '<p class="empty">장바구니가 비어 있어요.</p>'; return; }

  const sum = cartTotal();
  const ship = sum >= FREE_SHIPPING ? 0 : SHIPPING_FEE;
  const maxUse = currentUser ? Math.min(currentUser.points, sum + ship) : 0;

  box.innerHTML = `
    <div class="cart-list">
      ${cart.map(c => {
        const p = PRODUCTS.find(x => x.id === c.id);
        return `<div class="cart-row">
          <span class="cart-emoji">${p.emoji}</span>
          <span class="cart-name">${esc(p.name)}</span>
          <span class="qty">
            <button type="button" onclick="changeQty(${p.id}, -1)">−</button>
            <b>${c.qty}</b>
            <button type="button" onclick="changeQty(${p.id}, 1)">+</button>
          </span>
          <span class="cart-price">${won(p.price * c.qty)}</span>
        </div>`;
      }).join('')}
    </div>
    <div class="cart-summary">
      <p>상품 금액 <b>${won(sum)}</b></p>
      <p>배송비 <b>${ship ? won(ship) : '무료'}</b> <small>(${won(FREE_SHIPPING)} 이상 무료, 생물 전용 산소포장)</small></p>
      ${currentUser
        ? `<p>포인트 사용 <input type="number" id="use-points" min="0" max="${maxUse}" step="100" value="0" oninput="updateFinal(${sum + ship}, ${maxUse})">
             <small>보유 ${currentUser.points.toLocaleString()}P</small></p>`
        : `<p class="notice">로그인하면 포인트 사용 및 결제가 가능합니다.</p>`}
      <p class="final">최종 결제 금액 <b id="final-price">${won(sum + ship)}</b></p>
      <button type="button" class="btn-primary full-width" onclick="checkout()">${currentUser ? '결제하기 (체험)' : '로그인하고 결제하기'}</button>
    </div>`;
}

function updateFinal(base, maxUse) {
  const input = $('use-points');
  let v = Math.max(0, Math.min(maxUse, parseInt(input.value) || 0));
  input.value = v;
  $('final-price').textContent = won(base - v);
}

async function checkout() {
  if (!currentUser) { openAuthModal(); return; }
  const sum = cartTotal();
  const ship = sum >= FREE_SHIPPING ? 0 : SHIPPING_FEE;
  const used = Math.min(parseInt($('use-points').value) || 0, currentUser.points, sum + ship);
  const pay = sum + ship - used;
  const grade = gradeOf(currentUser.total_spent);
  const earned = Math.floor(pay * grade.rate);

  try {
    await DB.addOrder({
      member_email: currentUser.email,
      items: cart.map(c => ({ ...c, name: PRODUCTS.find(p => p.id === c.id).name, price: PRODUCTS.find(p => p.id === c.id).price })),
      total: pay, used_points: used, earned_points: earned
    });
    const spent = currentUser.total_spent + pay;
    currentUser = await DB.updateMember(currentUser.email, {
      points: currentUser.points - used + earned,
      total_spent: spent,
      grade: gradeOf(spent).name
    });
    cart = []; saveCart(); updateAuthUI();
    toast(`결제 완료! ${earned.toLocaleString()}P 적립 · 배송이 시작됩니다 🚚`);
    navigate('mypage');
  } catch (err) {
    toast(err.message, true);
  }
}

/* ---------- 마이페이지 ---------- */
async function renderMyPage() {
  const u = currentUser;
  const next = GRADES.find(g => g.min > u.total_spent);
  let orders = [];
  try { orders = await DB.getOrders(u.email); } catch (e) { toast(e.message, true); }

  $('mypage-content').innerHTML = `
    <div class="profile-card">
      <h3>${esc(u.name)}님 <span class="grade grade-${esc(u.grade)}">${esc(u.grade)}</span></h3>
      <p>이메일: ${esc(u.email)}</p>
      <p>연락처: ${esc(u.phone)}</p>
      <p>보유 포인트: <b>${u.points.toLocaleString()}P</b></p>
      <p>누적 구매: ${won(u.total_spent)} ${next ? `<small>(${next.name}까지 ${won(next.min - u.total_spent)})</small>` : ''}</p>
      <p><small>등급별 적립률: 브론즈 1% · 실버 2% · 골드 3%</small></p>
      <button type="button" class="btn-outline" onclick="logout()">로그아웃</button>
    </div>
    <h3 class="sub-title">주문 / 배송 내역</h3>
    ${orders.length ? orders.map(o => `
      <div class="order-card">
        <p><b>${new Date(o.created_at).toLocaleString('ko-KR')}</b> <span class="status">${esc(o.status)}</span></p>
        <p>${o.items.map(i => `${esc(i.name)} ×${i.qty}`).join(', ')}</p>
        <p>결제 ${won(o.total)} · 사용 ${o.used_points.toLocaleString()}P · 적립 ${o.earned_points.toLocaleString()}P</p>
      </div>`).join('') : '<p class="empty">주문 내역이 없습니다.</p>'}`;
}

/* ---------- 히어로 슬라이더 ---------- */
function initSlider() {
  const slides = document.querySelectorAll('#hero-slides .slide');
  const dots = $('slider-dots');
  let cur = 0;
  slides.forEach((_, i) => {
    const d = document.createElement('button');
    d.type = 'button';
    d.className = 'dot' + (i === 0 ? ' active' : '');
    d.onclick = () => go(i);
    dots.appendChild(d);
  });
  function go(i) {
    cur = i;
    slides.forEach((s, k) => s.classList.toggle('active', k === i));
    dots.querySelectorAll('.dot').forEach((d, k) => d.classList.toggle('active', k === i));
  }
  setInterval(() => go((cur + 1) % slides.length), 4000);
}

/* ---------- 시작 ---------- */
document.addEventListener('DOMContentLoaded', () => {
  initSlider();
  renderProducts();
  updateBadge();
  restoreSession();

  $('category-tabs').addEventListener('click', e => {
    const b = e.target.closest('.tab-btn');
    if (!b) return;
    activeCat = b.dataset.cat;
    document.querySelectorAll('.tab-btn').forEach(x => x.classList.toggle('active', x === b));
    renderProducts();
  });
  $('search-input').addEventListener('input', e => { searchKeyword = e.target.value; renderProducts(); });

  if (DB.mode === 'local') console.info('[AQUA WAVE] Supabase 키가 비어 있어 localStorage 모드로 동작 중입니다.');
});
