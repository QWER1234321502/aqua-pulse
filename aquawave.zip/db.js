/* ============================================================
   db.js  —  AQUA WAVE 데이터 계층 (테이블 접두어: shop_)
   - SUPABASE_URL / SUPABASE_ANON_KEY 를 채우면 Supabase 에 저장
   - 비워두면 브라우저 localStorage 에 저장 (바로 테스트 가능)
   ============================================================ */

// ▼▼▼ Supabase 대시보드 > Project Settings > API 에서 복사해 붙여넣기 ▼▼▼
const SUPABASE_URL = '';
const SUPABASE_ANON_KEY = '';
// ▲▲▲ ----------------------------------------------------- ▲▲▲

const SIGNUP_BONUS = 3000;

const USE_SUPABASE = !!(SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase);
const sb = USE_SUPABASE ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

/* ---------- 공통 유틸 ---------- */
async function hashPw(pw) {
  // 비밀번호 평문 저장 방지 (SHA-256)
  if (window.crypto && crypto.subtle) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('aquawave:' + pw));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  }
  let h = 0;
  for (const c of 'aquawave:' + pw) h = (h * 31 + c.charCodeAt(0)) | 0;
  return 'x' + h;
}

const LS = {
  get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
};

function publicMember(m) {
  if (!m) return null;
  const { password_hash, ...rest } = m;
  return rest;
}

/* ---------- DB API ---------- */
const DB = {
  mode: USE_SUPABASE ? 'supabase' : 'local',

  async getMember(email) {
    email = email.trim().toLowerCase();
    if (USE_SUPABASE) {
      const { data, error } = await sb.from('shop_members').select('*').eq('email', email).maybeSingle();
      if (error) throw new Error('회원 조회 실패: ' + error.message);
      return data;
    }
    return LS.get('shop_members', []).find(m => m.email === email) || null;
  },

  async signup({ name, phone, email, password }) {
    email = email.trim().toLowerCase();
    name = name.trim();
    phone = phone.trim();

    if (!name) throw new Error('이름을 입력해주세요.');
    if (!/^01[0-9]-?\d{3,4}-?\d{4}$/.test(phone)) throw new Error('연락처 형식을 확인해주세요. (예: 010-1234-5678)');
    if (password.length < 6) throw new Error('비밀번호는 6자 이상이어야 합니다.');
    if (await this.getMember(email)) throw new Error('이미 가입된 이메일입니다.');

    const member = {
      email, name, phone,
      password_hash: await hashPw(password),
      points: SIGNUP_BONUS,
      grade: '브론즈',
      total_spent: 0,
      created_at: new Date().toISOString()
    };

    if (USE_SUPABASE) {
      const { data, error } = await sb.from('shop_members').insert(member).select().single();
      if (error) {
        if (error.code === '23505') throw new Error('이미 가입된 이메일입니다.');
        throw new Error('회원가입 실패: ' + error.message);
      }
      return publicMember(data);
    }
    const list = LS.get('shop_members', []);
    list.push(member);
    LS.set('shop_members', list);
    return publicMember(member);
  },

  async login(email, password) {
    const m = await this.getMember(email);
    if (!m || m.password_hash !== await hashPw(password)) {
      throw new Error('이메일 또는 비밀번호가 올바르지 않습니다.');
    }
    return publicMember(m);
  },

  async updateMember(email, patch) {
    email = email.trim().toLowerCase();
    if (USE_SUPABASE) {
      const { data, error } = await sb.from('shop_members').update(patch).eq('email', email).select().single();
      if (error) throw new Error('회원 정보 수정 실패: ' + error.message);
      return publicMember(data);
    }
    const list = LS.get('shop_members', []);
    const i = list.findIndex(m => m.email === email);
    if (i < 0) throw new Error('회원 정보를 찾을 수 없습니다.');
    list[i] = { ...list[i], ...patch };
    LS.set('shop_members', list);
    return publicMember(list[i]);
  },

  async addOrder(order) {
    order = { ...order, created_at: new Date().toISOString(), status: '배송 준비중' };
    if (USE_SUPABASE) {
      const { data, error } = await sb.from('shop_orders').insert(order).select().single();
      if (error) throw new Error('주문 저장 실패: ' + error.message);
      return data;
    }
    const list = LS.get('shop_orders', []);
    order.id = Date.now();
    list.push(order);
    LS.set('shop_orders', list);
    return order;
  },

  async getOrders(email) {
    email = email.trim().toLowerCase();
    if (USE_SUPABASE) {
      const { data, error } = await sb.from('shop_orders').select('*').eq('member_email', email).order('created_at', { ascending: false });
      if (error) throw new Error('주문 조회 실패: ' + error.message);
      return data;
    }
    return LS.get('shop_orders', []).filter(o => o.member_email === email).reverse();
  }
};

/* ---------- 상품 데이터 (이모지로 표시, 별도 이미지 불필요) ---------- */
const PRODUCTS = [
  { id: 1,  cat: '소형 열대어',   name: '네온테트라',       emoji: '🐟', price: 1500,  desc: '푸른 형광 라인이 아름다운 군영 어종. 10마리 이상 무리 사육 추천.' },
  { id: 2,  cat: '소형 열대어',   name: '카디널테트라',     emoji: '🐠', price: 2500,  desc: '선명한 붉은 배가 돋보이는 테트라. 수초 어항에 잘 어울립니다.' },
  { id: 3,  cat: '소형 열대어',   name: '램프아이',         emoji: '✨', price: 2000,  desc: '투명한 몸에 반짝이는 눈. 온순해서 합사가 쉽습니다.' },
  { id: 4,  cat: '베타·구피',     name: '크라운테일 베타',  emoji: '🐡', price: 15000, desc: '왕관처럼 갈라진 지느러미. 1마리씩 단독 사육하세요.' },
  { id: 5,  cat: '베타·구피',     name: '하프문 베타',      emoji: '🌙', price: 22000, desc: '지느러미가 180도로 펼쳐지는 프리미엄 개체.' },
  { id: 6,  cat: '베타·구피',     name: '풀레드 구피',      emoji: '🎏', price: 3000,  desc: '번식이 쉬워 초보자에게 인기. 온몸이 붉은 개체.' },
  { id: 7,  cat: '대형·시클리드', name: '레드 디스커스',    emoji: '🔴', price: 85000, desc: '열대어의 황제. 선명한 발색, 산소포장 당일 출고.' },
  { id: 8,  cat: '대형·시클리드', name: '엔젤피쉬',         emoji: '👼', price: 6000,  desc: '우아한 삼각형 실루엣. 150cm 이상 어항 권장.' },
  { id: 9,  cat: '대형·시클리드', name: '아로와나 (유어)',  emoji: '🐉', price: 120000, desc: '용고기라 불리는 대형 어종. 뚜껑 필수.' },
  { id: 10, cat: '바닥청소·새우', name: '코리도라스',       emoji: '🐋', price: 3500,  desc: '바닥 청소 담당. 5마리 이상 무리 사육 추천.' },
  { id: 11, cat: '바닥청소·새우', name: '레드체리 새우',    emoji: '🦐', price: 1800,  desc: '수초 어항의 활력소. 초보자도 쉽게 기릅니다.' },
  { id: 12, cat: '바닥청소·새우', name: '플레코',           emoji: '🦎', price: 8000,  desc: '유리면 이끼 제거 전문가. 야행성.' }
];
